import Test.Hspec

main :: IO ()
main = hspec $
  describe "Testing head function" $
    it "Head should return the first element in the list" $
      head [2..] `ShouldBe` 2